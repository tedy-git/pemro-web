<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
require_once 'config/database.php';

$type = isset($_GET['type']) ? $_GET['type'] : '';
$category = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT t.*, c.name as category_name FROM tutorials t 
          LEFT JOIN categories c ON t.category_id = c.id 
          WHERE 1=1";

$params = [];

if ($type) {
    $query .= " AND c.type = ?";
    $params[] = $type;
}

if ($category) {
    $query .= " AND t.category_id = ?";
    $params[] = $category;
}

if ($search) {
    $query .= " AND (t.title LIKE ? OR t.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";

    // Simpan riwayat pencarian jika user login
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("INSERT INTO search_history (user_id, query) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $search]);
    }
}

$query .= " ORDER BY t.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$tutorials = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil kategori untuk filter
$categories = [];
if ($type) {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE type = ?");
    $stmt->execute([$type]);
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutorial Perbaikan - Velocity Service</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/tutorial.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <section class="tutorial-header">
            <h1>Tutorial Perbaikan Kendaraan</h1>
            <form action="tutorials.php" method="GET" class="search-form">
                <input type="text" name="search" placeholder="Cari tutorial..."
                    value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Cari</button>
            </form>
        </section>

        <section class="filters">
            <h2>Filter</h2>
            <div class="filter-options">
                <div class="filter-group">
                    <label for="type">Jenis Kendaraan:</label>
                    <select id="type" onchange="location = this.value;">
                        <option value="tutorials.php" <?php echo !$type ? 'selected' : ''; ?>>Semua</option>
                        <option value="tutorials.php?type=motor" <?php echo $type === 'motor' ? 'selected' : ''; ?>>Motor
                        </option>
                        <option value="tutorials.php?type=mobil" <?php echo $type === 'mobil' ? 'selected' : ''; ?>>Mobil
                        </option>
                    </select>
                </div>

                <?php if ($type && $categories): ?>
                    <div class="filter-group">
                        <label for="category">Kategori:</label>
                        <select id="category"
                            onchange="location = 'tutorials.php?type=<?php echo $type; ?>&category=' + this.value;">
                            <option value="0">Semua</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo $category === $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="tutorial-list">
            <?php if (empty($tutorials)): ?>
                <p class="no-results">Tidak ada tutorial yang ditemukan.</p>
            <?php else: ?>
                <div class="tutorial-grid">
                    <?php foreach ($tutorials as $tutorial): ?>
                        <div class="tutorial-card">
                            <div class="video-container">
                                <video controls width="100%">
                                    <source src="<?php echo htmlspecialchars($tutorial['video_url']); ?>" type="video/mp4">
                                    Browser Anda tidak mendukung pemutar video.
                                </video>
                            </div>
                            <div class="tutorial-info">
                                <h3><?php echo htmlspecialchars($tutorial['title']); ?></h3>
                                <div class="meta">
                                    <span
                                        class="category"><?php echo htmlspecialchars($tutorial['category_name'] ?? 'Umum'); ?></span>
                                    <span class="difficulty <?php echo htmlspecialchars($tutorial['difficulty']); ?>">
                                        <?php
                                        $difficulty_map = [
                                            'pemula' => 'Pemula',
                                            'menengah' => 'Menengah',
                                            'mahir' => 'Mahir'
                                        ];
                                        echo $difficulty_map[$tutorial['difficulty']];
                                        ?>
                                    </span>
                                    <span class="duration"><?php echo htmlspecialchars($tutorial['duration']); ?> menit</span>
                                </div>
                                <p><?php echo substr(htmlspecialchars($tutorial['description']), 0, 150); ?>...</p>
                                <a href="tutorial_detail.php?id=<?php echo $tutorial['id']; ?>" class="btn">Lihat Tutorial</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>

</html>