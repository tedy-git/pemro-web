<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/admin_sidebar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <title>Document</title>
</head>
<body>
    <?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

    <div class="admin-sidebar">
    <div class="admin-profile">
        <div class="profile-icon">
            <i class="fas fa-user-cog"></i>
        </div>
        <div class="profile-info">
            <h4><?php echo htmlspecialchars($_SESSION['username']); ?></h4>

        </div>
    </div>

    <ul class="admin-menu">
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <a href="dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'manage_videos.php' ? 'active' : ''; ?>">
            <a href="manage_videos.php">
                <i class="fas fa-video"></i>
                <span>Kelola Video Tutorial</span>
            </a>
        </li>
        
        
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'manage_users.php' ? 'active' : ''; ?>">
            <a href="manage_users.php">
                <i class="fas fa-users"></i>
                <span>Kelola Pengguna</span>
            </a>
        </li>
        
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'manage_comments.php' ? 'active' : ''; ?>">
            <a href="manage_comments.php">
                <i class="fas fa-comments"></i>
                <span>Kelola Komentar</span>
            </a>
        </li>
        
        <li class="menu-divider"></li>
        
    </ul>
</div>

</body>
</html>