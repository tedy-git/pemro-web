<?php
session_start();
require_once '../config/database.php';

// Cek apakah user adalah admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Hitung jumlah data
$stmt = $pdo->query("SELECT COUNT(*) as total FROM tutorials");
$tutorials_count = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
$users_count = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM categories");
$categories_count = $stmt->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Velocity Service</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <?php include '../includes/header_admin.php'; ?>

    <div class="admin-container">
        <?php include 'admin_sidebar.php'; ?>

        <main class="admin-content">
            <h1>Dashboard Admin</h1>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Tutorial</h3>
                    <p><?php echo $tutorials_count; ?></p>
                    <a href="manage_videos.php">Kelola</a>
                </div>
                
                <div class="stat-card">
                    <h3>Pengguna</h3>
                    <p><?php echo $users_count; ?></p>
                    <a href="manage_users.php">Kelola</a>
                </div>
                
                <div class="stat-card">
                    <h3>Kategori</h3>
                    <p><?php echo $categories_count; ?></p>
                    <a href="manage_videos.php?action=categories">Kelola</a>
                </div>
            </div>
            
            <div class="recent-activity">
                <h2>Aktivitas Terkini</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Aktivitas</th>
                            <th>Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT sh.id, u.username, sh.query, sh.created_at 
                                            FROM search_history sh
                                            JOIN users u ON sh.user_id = u.id
                                            ORDER BY sh.created_at DESC LIMIT 5");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($row['id'] ?? '') . '</td>';
                            echo '<td>' . htmlspecialchars($row['username']) . '</td>';
                            echo '<td>Mencari: "' . htmlspecialchars($row['query']) . '"</td>';
                            echo '<td>' . htmlspecialchars($row['created_at']) . '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>