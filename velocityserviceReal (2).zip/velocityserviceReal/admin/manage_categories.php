<?php
session_start();
require_once '../config/database.php';

// Cek apakah user adalah admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Tambah kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $type = $_POST['type'];

    if (!empty($name) && in_array($type, ['motor', 'mobil'])) {
        $stmt = $pdo->prepare("INSERT INTO categories (name, type) VALUES (?, ?)");
        $stmt->execute([$name, $type]);

        $_SESSION['message'] = 'Kategori berhasil ditambahkan.';
    }

    header('Location: manage_videos.php?action=categories');
    exit;
}

// Hapus kategori
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    $id = (int) $_GET['id'];

    // Cek apakah ada tutorial yang menggunakan kategori ini
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tutorials WHERE category_id = ?");
    $stmt->execute([$id]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        $_SESSION['message'] = 'Kategori tidak dapat dihapus karena masih digunakan dalam tutorial.';
    } else {
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['message'] = 'Kategori berhasil dihapus.';
    }

    header('Location: manage_videos.php?action=categories');
    exit;
}

// Jika tidak ada aksi, kembali ke halaman kelola
header('Location: manage_videos.php?action=categories');
exit;

