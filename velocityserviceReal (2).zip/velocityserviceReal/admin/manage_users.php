<?php
session_start();
require_once '../config/database.php';

// Cek apakah user adalah admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'edit') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
        $stmt->execute([$username, $email, $role, $id]);
        $_SESSION['message'] = 'Pengguna berhasil diperbarui';
        
        header('Location: manage_users.php');
        exit;
    }
}

if ($action === 'delete' && $id) {
    // Jangan izinkan menghapus diri sendiri
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['message'] = 'Pengguna berhasil dihapus';
    } else {
        $_SESSION['message'] = 'Tidak dapat menghapus akun sendiri';
    }
    
    header('Location: manage_users.php');
    exit;
}

// Ambil data pengguna untuk form edit
$user = null;
if ($action === 'edit' && $id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        header('Location: manage_users.php');
        exit;
    }
}

// Ambil semua pengguna untuk list
$stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengguna - Velocity Service</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <?php include '../includes/header_admin.php'; ?>

    <div class="admin-container">
        <?php include 'admin_sidebar.php'; ?>

        <main class="admin-content">
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
            <?php endif; ?>
            
            <?php if ($action === 'list'): ?>
                <div class="admin-header">
                    <h1>Kelola Pengguna</h1>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Tanggal Daftar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><?php echo $u['id']; ?></td>
                                <td><?php echo htmlspecialchars($u['username']); ?></td>
                                <td><?php echo htmlspecialchars($u['email']); ?></td>
                                <td><?php echo htmlspecialchars($u['role'] === 'admin' ? 'Admin' : 'User'); ?></td>
                                <td><?php echo htmlspecialchars($u['created_at']); ?></td>
                                <td class="actions">
                                    <a href="?action=edit&id=<?php echo $u['id']; ?>" class="btn small">Edit</a>
                                    <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                        <a href="?action=delete&id=<?php echo $u['id']; ?>" class="btn small danger" onclick="return confirm('Apakah Anda yakin?')">Hapus</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h1>Edit Pengguna</h1>
                
                <form method="POST" class="user-form">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" required>
                            <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                            <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn">Simpan</button>
                        <a href="manage_users.php" class="btn secondary">Batal</a>
                    </div>
                </form>
            <?php endif; ?>
        </main>
    </div>

    
</body>
</html>