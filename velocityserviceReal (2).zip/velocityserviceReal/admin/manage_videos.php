<?php
session_start();
require_once '../config/database.php';

// Cek apakah user adalah admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Jika ada file yang diunggah
    if (isset($_FILES['video_file']) && $_FILES['video_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['video_file']['tmp_name'];
        $file_name = basename($_FILES['video_file']['name']);
        $file_size = $_FILES['video_file']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed = ['mp4'];
        $max_size = 1000 * 1024 * 1024; // 50MB

        if (in_array($file_ext, $allowed) && $file_size <= $max_size) {
            $new_name = uniqid('vid_') . '.' . $file_ext;
            $upload_path = '../uploads/videos/' . $new_name;

            if (!is_dir('../uploads/videos')) {
                mkdir('../uploads/videos', 0777, true);
            }

            if (move_uploaded_file($file_tmp, $upload_path)) {
                $video_url = 'uploads/videos/' . $new_name; // Simpan relatif path
            }
        }
    }

    if ($action === 'add' || $action === 'edit') {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $category_id = $_POST['category_id'] ? (int) $_POST['category_id'] : NULL;
        $difficulty = $_POST['difficulty'];
        $duration = (int) $_POST['duration'];

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO tutorials (title, description, category_id, difficulty, duration, video_url) 
                       VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $description, $category_id, $difficulty, $duration, $video_url ?? null]);

            $_SESSION['message'] = 'Tutorial berhasil ditambahkan';
        } else {
            if (!empty($video_url)) {
                $stmt = $pdo->prepare("UPDATE tutorials SET 
        title = ?, description = ?, video_url = ?, 
        category_id = ?, difficulty = ?, duration = ?
        WHERE id = ?");
                $stmt->execute([$title, $description, $video_url, $category_id, $difficulty, $duration, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE tutorials SET 
        title = ?, description = ?, 
        category_id = ?, difficulty = ?, duration = ?
        WHERE id = ?");
                $stmt->execute([$title, $description, $category_id, $difficulty, $duration, $id]);
            }

            $_SESSION['message'] = 'Tutorial berhasil diperbarui';
        }

        header('Location: manage_videos.php');
        exit;
    }
}

if ($action === 'delete' && $id) {
    $stmt = $pdo->prepare("DELETE FROM tutorials WHERE id = ?");
    $stmt->execute([$id]);
    $_SESSION['message'] = 'Tutorial berhasil dihapus';
    header('Location: manage_videos.php');
    exit;
}

// Ambil data untuk form edit
$tutorial = null;
if ($action === 'edit' && $id) {
    $stmt = $pdo->prepare("SELECT * FROM tutorials WHERE id = ?");
    $stmt->execute([$id]);
    $tutorial = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tutorial) {
        header('Location: manage_videos.php');
        exit;
    }
}

if ($action === 'delete' && $id) {
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    $_SESSION['message'] = 'Tutorial berhasil dihapus';
    header('Location: manage_videos.php');
    exit;
}
// Ambil semua tutorial untuk list
$stmt = $pdo->query("SELECT t.*, c.name as category_name 
                    FROM tutorials t 
                    LEFT JOIN categories c ON t.category_id = c.id 
                    ORDER BY t.created_at DESC");
$tutorials = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil kategori untuk dropdown
$stmt = $pdo->query("SELECT * FROM categories ORDER BY type, name");
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Video Tutorial - Velocity Service</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>

<body>
    <?php include '../includes/header_admin.php'; ?>

    <div class="admin-container">
        <?php include 'admin_sidebar.php'; ?>

        <main class="admin-content">
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert success"><?php echo $_SESSION['message'];
                unset($_SESSION['message']); ?></div>
            <?php endif; ?>

            <?php if ($action === 'list' || $action === 'categories'): ?>
                <div class="admin-header">
                    <h1><?php echo $action === 'categories' ? 'Kelola Kategori' : 'Kelola Video Tutorial'; ?></h1>
                    <a href="?action=add" class="btn">Tambah Vidio</a>
                    <a href="?action=categories" class="btn">Kelola Kategori</a>
                </div>

                <?php if ($action === 'list'): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Kesulitan</th>
                                <th>Durasi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tutorials as $t): ?>
                                <tr>
                                    <td><?php echo $t['id']; ?></td>
                                    <td><?php echo htmlspecialchars($t['title']); ?></td>
                                    <td><?php echo htmlspecialchars($t['category_name'] ?? '-'); ?></td>
                                    <td>
                                        <?php
                                        $difficulty_map = [
                                            'pemula' => 'Pemula',
                                            'menengah' => 'Menengah',
                                            'mahir' => 'Mahir'
                                        ];
                                        echo $difficulty_map[$t['difficulty']];
                                        ?>
                                    </td>
                                    <td><?php echo $t['duration']; ?> menit</td>
                                    <td class="actions">
                                        <a href="?action=edit&id=<?php echo $t['id']; ?>" class="btn small">Edit</a>
                                        <a href="?action=delete&id=<?php echo $t['id']; ?>" class="btn small danger"
                                            onclick="return confirm('Apakah Anda yakin?')">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <!-- Form untuk mengelola kategori -->
                    <form action="manage_categories.php" method="POST" class="category-form">
                        <div class="form-group">
                            <label for="name">Nama Kategori</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="type">Jenis Kendaraan</label>
                            <select id="type" name="type" required>
                                <option value="motor">Motor</option>
                                <option value="mobil">Mobil</option>
                            </select>
                        </div>
                        <button type="submit" class="btn">Tambah Kategori</button>
                    </form>

                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Jenis</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $cat): ?>
                                <tr>
                                    <td><?php echo $cat['id']; ?></td>
                                    <td><?php echo htmlspecialchars($cat['name']); ?></td>
                                    <td><?php echo htmlspecialchars($cat['type'] === 'motor' ? 'Motor' : 'Mobil'); ?></td>
                                    <td class="actions">
                                        <a href="manage_categories.php?action=delete&id=<?php echo $cat['id']; ?>"
                                            class="btn small danger" onclick="return confirm('Apakah Anda yakin?')">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            <?php else: ?>
                <h1><?php echo $action === 'add' ? 'Tambah Video Tutorial' : 'Edit Video Tutorial'; ?></h1>

                <form method="POST" enctype="multipart/form-data" class="tutorial-form">
                    <div class="form-group">
                        <label for="title">Judul</label>
                        <input type="text" id="title" name="title"
                            value="<?php echo htmlspecialchars($tutorial['title'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Deskripsi</label>
                        <textarea id="description" name="description" rows="5"
                            required><?php echo htmlspecialchars($tutorial['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="video_file">Upload Video (mp4, max 1gb)</label>
                        <input type="file" id="video_file" name="video_file" accept="video/mp4">
                        <?php if (!empty($tutorial['video_url'])): ?>
                            <video width="320" height="240" controls>
                                <source src="../<?php echo htmlspecialchars($tutorial['video_url']); ?>" type="video/mp4">
                                Browser tidak mendukung video tag.
                            </video>
                        <?php endif; ?>

                    </div>


                    <div class="form-row">
                        <div class="form-group">
                            <label for="category_id">Kategori</label>
                            <select id="category_id" name="category_id">
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>" <?php echo (isset($tutorial['category_id']) && $tutorial['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                        (<?php echo htmlspecialchars($cat['type'] === 'motor' ? 'Motor' : 'Mobil'); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="difficulty">Tingkat Kesulitan</label>
                            <select id="difficulty" name="difficulty" required>
                                <option value="pemula" <?php echo (isset($tutorial['difficulty']) && $tutorial['difficulty'] === 'pemula') ? 'selected' : ''; ?>>Pemula</option>
                                <option value="menengah" <?php echo (isset($tutorial['difficulty']) && $tutorial['difficulty'] === 'menengah') ? 'selected' : ''; ?>>Menengah</option>
                                <option value="mahir" <?php echo (isset($tutorial['difficulty']) && $tutorial['difficulty'] === 'mahir') ? 'selected' : ''; ?>>Mahir</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="duration">Durasi (menit)</label>
                            <input type="number" id="duration" name="duration" min="1"
                                value="<?php echo $tutorial['duration'] ?? '10'; ?>" required>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn">Simpan</button>
                        <a href="manage_videos.php" class="btn secondary">Batal</a>
                    </div>
                </form>
            <?php endif; ?>
        </main>
    </div>

    
</body>

</html>