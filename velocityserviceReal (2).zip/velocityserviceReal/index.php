<?php
session_start();
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="id">

<head>  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Velocity Service - Tutorial Perbaikan Kendaraan</title>
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/style.css">
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/home.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <section class="hero">
            <h1>Belajar Memperbaiki Kendaraan Anda Sendiri</h1>
            <p>Temukan ratusan tutorial perbaikan motor dan mobil dari para ahli</p>
            <a href="tutorials.php" class="btn">Jelajahi Tutorial</a>
        </section>

        <section class="featured-tutorials">
            <h2>Tutorial Populer</h2>
            <div class="tutorial-grid">
                <?php
                $stmt = $pdo->query("SELECT * FROM tutorials ORDER BY created_at DESC LIMIT 3");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<div class="tutorial-card">';
                    echo '<div class="video-container">
    <video controls width="100%">
        <source src="' . htmlspecialchars($row['video_url']) . '" type="video/mp4">
        Browser Anda tidak mendukung pemutar video.
    </video>
</div>';



                    echo '<h3>' . htmlspecialchars($row['title']) . '</h3>';
                    echo '<p>' . substr(htmlspecialchars($row['description']), 0, 100) . '...</p>';
                    echo '<a href="tutorial_detail.php?id=' . $row['id'] . '" class="btn">Lihat Tutorial</a>';
                    echo '</div>';
                }
                ?>
            </div>
        </section>

        <section class="categories">
            <h2>Kategori</h2>
            <div class="category-grid">
                <div class="category-card motor">
                    <h3>Motor</h3>
                    <p>Tutorial perbaikan sepeda motor</p>
                    <a href="tutorials.php?type=motor" class="btn">Lihat Tutorial</a>
                </div>
                <div class="category-card mobil">
                    <h3>Mobil</h3>
                    <p>Tutorial perbaikan mobil</p>
                    <a href="tutorials.php?type=mobil" class="btn">Lihat Tutorial</a>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="/velocityserviceReal/assets/js/script.js"></script>
</body>

</html>