<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - Velocity Service</title>
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/style.css">
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/about.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <section class="about-hero">
            <h1>Tentang Velocity Service</h1>
            <p>Platform pembelajaran perbaikan kendaraan terbaik di Indonesia</p>
        </section>

        <section class="about-content">
            <div class="container">
                <h2>Visi Kami</h2>
                <p>Velocity Service hadir untuk memudahkan setiap pemilik kendaraan motor dan mobil dalam mempelajari cara memperbaiki masalah pada kendaraan mereka sendiri. Kami percaya bahwa pengetahuan dasar perbaikan kendaraan seharusnya dapat diakses oleh semua orang.</p>
                
                <h2>Misi Kami</h2>
                <p>1. Menyediakan tutorial perbaikan kendaraan yang mudah dipahami dan dapat diikuti oleh pemula</p>
                <p>2. Membangun komunitas pecinta otomotif yang saling berbagi pengetahuan</p>
                <p>3. Mengurangi biaya perbaikan kendaraan dengan memungkinkan pemilik memperbaiki masalah sederhana sendiri</p>
                
                <h2>Tim Kami</h2>
                <div class="team-grid">
                    <div class="team-member">
                        <div class="member-photo"></div>
                        <h3>Tedy Permadi</h3>
                        <p>Backend</p>
                    </div>
                    <div class="team-member">
                        <div class="member-photo"></div>
                        <h3>Arsa</h3>
                        <p>Backend</p>
                        
                    </div>
                    <div class="team-member">
                        <div class="member-photo"></div>
                        <h3>Fauzan</h3>
                        <p>Backend</p>
                        
                    </div>
                    <div class="team-member">
                        <div class="member-photo" style="background-image: url"></div>
                        <h3>Erika</h3>
                        <p>Frontend & table database</p>
                      
                    </div>
                     <div class="team-member">
                        <div class="member-photo"></div>
                        <h3>Rafi</h3>
                        <p>content creator</p>
                     
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>