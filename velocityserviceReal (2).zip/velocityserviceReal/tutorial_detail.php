<?php
session_start();
require_once 'config/database.php';
function removeAutoplay($url) {
    $parsed = parse_url($url);
    if (!isset($parsed['query'])) return $url;

    parse_str($parsed['query'], $params);
    unset($params['autoplay']);
    $query = http_build_query($params);

    $final = $parsed['scheme'] . '://' . $parsed['host'] . $parsed['path'];
    if (!empty($query)) {
        $final .= '?' . $query;
    }
    return $final;
}

if (!isset($_GET['id'])) {
    header('Location: tutorials.php');
    exit;
}

$id = (int)$_GET['id'];
$stmt = $pdo->prepare("SELECT t.*, c.name as category_name, c.type as vehicle_type 
                      FROM tutorials t 
                      LEFT JOIN categories c ON t.category_id = c.id 
                      WHERE t.id = ?");
$stmt->execute([$id]);
$tutorial = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$tutorial) {
    header('Location: tutorials.php');
    exit;
}

// Ambil tutorial terkait
$stmt = $pdo->prepare("SELECT * FROM tutorials WHERE category_id = ? AND id != ? ORDER BY RAND() LIMIT 3");
$stmt->execute([$tutorial['category_id'], $id]);
$related_tutorials = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($tutorial['title']); ?> - Velocity Service</title>
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/style.css">
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/tutorial.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<main>
    <section class="tutorial-detail">
        <!-- Judul -->
        <h1><?php echo htmlspecialchars($tutorial['title']); ?></h1>

        <!-- Video -->
        <div class="video-container">
            <video controls width="100%">
    <source src="<?php echo htmlspecialchars($tutorial['video_url']); ?>" type="video/mp4">
    Browser Anda tidak mendukung HTML5 video.
</video>


        </div>

        <!-- Meta info -->
        <div class="meta">
            <span class="category"><?php echo htmlspecialchars($tutorial['category_name'] ?? 'Umum'); ?></span>
            <span class="vehicle-type"><?php echo htmlspecialchars($tutorial['vehicle_type'] === 'motor' ? 'Motor' : 'Mobil'); ?></span>
            <span class="difficulty <?php echo htmlspecialchars($tutorial['difficulty']); ?>">
                <?php
                $map = ['pemula' => 'Pemula', 'menengah' => 'Menengah', 'mahir' => 'Mahir'];
                echo $map[$tutorial['difficulty']];
                ?>
            </span>
            <span class="duration"><?php echo htmlspecialchars($tutorial['duration']); ?> menit</span>
        </div>

        <!-- Deskripsi -->
        <div class="description">
            <h2>Deskripsi</h2>
            <p><?php echo nl2br(htmlspecialchars($tutorial['description'])); ?></p>
        </div>

        <!-- Admin actions -->
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div class="admin-actions">
            <a href="admin/manage_videos.php?action=edit&id=<?php echo $tutorial['id']; ?>" class="btn">Edit</a>
            <a href="admin/manage_videos.php?action=delete&id=<?php echo $tutorial['id']; ?>" class="btn danger" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
        </div>
        <?php endif; ?>
    </section>

    <!-- Tutorial Terkait -->
    <?php if (!empty($related_tutorials)): ?>
    <section class="related-tutorials">
        <h2>Tutorial Terkait</h2>
        <div class="tutorial-grid">
            <?php foreach ($related_tutorials as $related): ?>
            <div class="tutorial-card">
                <div class="video-container">
                    <iframe src="<?php echo htmlspecialchars(removeAutoplay($related['video_url'])); ?>" frameborder="0" allowfullscreen></iframe>
                </div>
                <div class="tutorial-info">
                    <h3><?php echo htmlspecialchars($related['title']); ?></h3>
                    <a href="tutorial_detail.php?id=<?php echo $related['id']; ?>" class="btn">Lihat Tutorial</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
