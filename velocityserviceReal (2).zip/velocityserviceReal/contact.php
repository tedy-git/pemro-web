<?php
session_start();
require_once 'config/database.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message_content = $_POST['message'];
    
    // Validasi sederhana
    if (empty($name) || empty($email) || empty($subject) || empty($message_content)) {
        $error = 'Harap isi semua field yang diperlukan';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } else {
        // Simpan ke database (jika ada tabel contacts)
        try {
            $stmt = $pdo->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $subject, $message_content]);
            $message = 'Pesan Anda telah terkirim. Terima kasih!';
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan saat mengirim pesan: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak - Velocity Service</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/contact.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <section class="contact-hero">
            <h1>Hubungi Kami</h1>
            <p>Punya pertanyaan atau masukan? Kami siap membantu!</p>
        </section>

        <section class="contact-content">
            <div class="container">
                <div class="contact-form">
                    <h2>Kirim Pesan</h2>
                    
                    <?php if ($message): ?>
                        <div class="alert success"><?php echo $message; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert error"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <form action="contact.php" method="POST">
                        <div class="form-group">
                            <label for="name">Nama</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="subject">Subjek</label>
                            <input type="text" id="subject" name="subject" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="message">Pesan</label>
                            <textarea id="message" name="message" rows="5" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn">Kirim Pesan</button>
                    </form>
                </div>
                
                <div class="contact-info">
                    <h2>Informasi Kontak</h2>
                    <div class="info-item">
                        <h3>Alamat</h3>
                        <p>Jl. Otomotif No. 123, Daerah Istimewa Yogyakarta, Indonesia</p>
                    </div>
                    
                    <div class="info-item">
                        <h3>Email</h3>
                        <p>info@velocityservice.com</p>
                    </div>
                    
                    <div class="info-item">
                        <h3>Telepon</h3>
                        <p>(021) 1234-5678</p>
                    </div>
                    
                    <div class="info-item">
                        <h3>Jam Operasional</h3>
                        <p>Senin - Jumat: 09:00 - 17:00</p>
                        <p>Sabtu: 09:00 - 14:00</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>