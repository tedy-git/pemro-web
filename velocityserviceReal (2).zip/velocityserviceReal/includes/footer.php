<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/footer.css">
</head>
<body>
    <footer class="site-footer">
    <div class="container">
        <div class="footer-column">
            <h3>Velocity Service</h3>
            <p>Platform pembelajaran perbaikan kendaraan motor dan mobil secara mandiri melalui video tutorial.</p>
        </div>
        
        <div class="footer-column">
            <h3>Menu</h3>
            <ul>
                <li><a href="index.php">Beranda</a></li>
                <li><a href="tutorials.php">Tutorial</a></li>
                <li><a href="about.php">Tentang Kami</a></li>
                <li><a href="contact.php">Kontak</a></li>
            </ul>
        </div>
        
        <div class="footer-column">
            <h3>Kategori</h3>
            <ul>
                <li><a href="tutorials.php?type=motor">Motor</a></li>
                <li><a href="tutorials.php?type=mobil">Mobil</a></li>
            </ul>
        </div>
        
        <div class="footer-column">
            <h3>Hubungi Kami</h3>
            <p>Email: info@velocityservice.com</p>
            <p>Telepon: (021) 1234-5678</p>
            <p>WA: 08123456789</p>
            <div class="social-links">
                <a href="#">Facebook</a>
                <a href="#">Instagram</a>
                <a href="#">YouTube</a>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> Velocity Service. Semua hak dilindungi.</p>
    </div>
</footer>

<script src="/velocity-service/assets/js/script.js"></script>
</body>
</html>