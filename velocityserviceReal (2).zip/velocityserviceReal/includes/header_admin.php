<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = basename($_SERVER['PHP_SELF']);
$base_url = '/velocityserviceReal'; // Ganti sesuai nama folder project kamu
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Velocity Service - Tutorial Perbaikan Kendaraan</title>
    <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo $base_url; ?>/admin/dashboard.php">
                    <img src="<?php echo $base_url; ?>/assets/images/logo.png" alt="Velocity Service">
                    <span>Velocity Service</span>
                </a>
            </div>

            <div class="auth-buttons">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="user-dropdown">
                        <button class="user-btn">
                            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="dropdown-icon">▼</i>
                        </button>
                        <div class="dropdown-content">
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <?php endif; ?>
                            <a href="<?php echo $base_url; ?>/logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?php echo $base_url; ?>/login.php" class="btn">Login</a>
                    <a href="<?php echo $base_url; ?>/register.php" class="btn secondary">Daftar</a>
                <?php endif; ?>
            </div>

            <button class="mobile-menu-btn">☰</button>
        </div>
    </header>

    <div class="mobile-menu">
        <nav>
            <ul>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="<?php echo $base_url; ?>/profile.php">Profil</a></li>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                
                    <?php endif; ?>
                    <li><a href="<?php echo $base_url; ?>/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="<?php echo $base_url; ?>/login.php">Login</a></li>
                    <li><a href="<?php echo $base_url; ?>/register.php">Daftar</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</body>
</html>
