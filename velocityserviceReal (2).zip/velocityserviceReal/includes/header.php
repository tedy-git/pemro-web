<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Velocity Service - Tutorial Perbaikan Kendaraan</title>
    <link rel="stylesheet" href="/velocityserviceReal/assets/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <div class="logo">
                <a href="index.php">
                    <img src="assets/images/logo.png" alt="Velocity Service">
                    <span>Velocity Service</span>
                </a>
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php" class="<?php echo $current_page === 'index.php' ? 'active' : ''; ?>">Beranda</a></li>
                    <li><a href="tutorials.php" class="<?php echo $current_page === 'tutorials.php' || $current_page === 'tutorial_detail.php' ? 'active' : ''; ?>">Tutorial</a></li>
                    <li><a href="about.php" class="<?php echo $current_page === 'about.php' ? 'active' : ''; ?>">Tentang Kami</a></li>
                    <li><a href="contact.php" class="<?php echo $current_page === 'contact.php' ? 'active' : ''; ?>">Kontak</a></li>
                </ul>
            </nav>
            
            <div class="auth-buttons">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="user-dropdown">
                        <button class="user-btn">
                            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="dropdown-icon">▼</i>
                        </button>
                        <div class="dropdown-content">
                            <a href="profile.php">Profil</a>
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                <a href="admin/dashboard.php">Admin Panel</a>
                            <?php endif; ?>
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="btn">Login</a>
                    <a href="register.php" class="btn secondary">Daftar</a>
                <?php endif; ?>
            </div>
            
            <button class="mobile-menu-btn">☰</button>
        </div>
    </header>

    <div class="mobile-menu">
        <nav>
            <ul>
                <li><a href="index.php">Beranda</a></li>
                <li><a href="tutorials.php">Tutorial</a></li>
                <li><a href="about.php">Tentang Kami</a></li>
                <li><a href="contact.php">Kontak</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="profile.php">Profil</a></li>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <li><a href="admin/dashboard.php">Admin Panel</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Daftar</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
    </body>
    </html>