<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Ambil data user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle update profile
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];

    // Validasi
    if (empty($username) || empty($email)) {
        $error = 'Harap isi semua field';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } else {
        // Cek apakah username atau email sudah digunakan oleh orang lain
        $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $stmt->execute([$username, $email, $user_id]);

        if ($stmt->rowCount() > 0) {
            $error = 'Username atau email sudah digunakan';
        } else {
            // Update data
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
            if ($stmt->execute([$username, $email, $user_id])) {
                $_SESSION['username'] = $username;
                $user['username'] = $username;
                $user['email'] = $email;
                $message = 'Profil berhasil diperbarui';
            } else {
                $error = 'Gagal memperbarui profil';
            }
        }
    }
}

// Handle change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'Harap isi semua field password';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Password baru tidak sama';
    } elseif (!password_verify($current_password, $user['password'])) {
        $error = 'Password saat ini salah';
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        if ($stmt->execute([$hashed_password, $user_id])) {
            $message = 'Password berhasil diubah';
        } else {
            $error = 'Gagal mengubah password';
        }
    }
}
// Handle delete account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_account'])) {
    // Hapus riwayat pencarian (opsional)
    $stmt = $pdo->prepare("DELETE FROM search_history WHERE user_id = ?");
    $stmt->execute([$user_id]);

    // Hapus akun dari tabel users
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    if ($stmt->execute([$user_id])) {
        session_destroy();
        header('Location: login.php'); // Atau bisa ke index.php
        exit;
    } else {
        $error = 'Gagal menghapus akun';
    }
}


// Ambil riwayat pencarian
$stmt = $pdo->prepare("SELECT * FROM search_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$user_id]);
$search_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Velocity Service</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/profile.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <section class="profile-header">
            <div class="container">
                <h1>Profil Pengguna</h1>
                <p>Kelola informasi profil dan akun Anda</p>
            </div>
        </section>

        <section class="profile-content">
            <div class="container">
                <?php if ($message): ?>
                    <div class="alert success"><?php echo $message; ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert error"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="profile-grid">
                    <div class="profile-card">
                        <h2>Informasi Profil</h2>
                        <form method="POST">
                            <input type="hidden" name="update_profile" value="1">

                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" id="username" name="username"
                                    value="<?php echo htmlspecialchars($user['username']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email"
                                    value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Role</label>
                                <input type="text"
                                    value="<?php echo htmlspecialchars($user['role'] === 'admin' ? 'Admin' : 'User'); ?>"
                                    readonly>
                            </div>

                            <div class="form-group">
                                <label>Tanggal Daftar</label>
                                <input type="text" value="<?php echo htmlspecialchars($user['created_at']); ?>"
                                    readonly>
                            </div>

                            <button type="submit" class="btn">Perbarui Profil</button>
                        </form>
                    </div>

                    <div class="profile-card">
                        <h2>Ubah Password</h2>
                        <form method="POST">
                            <input type="hidden" name="change_password" value="1">

                            <div class="form-group">
                                <label for="current_password">Password Saat Ini</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>

                            <div class="form-group">
                                <label for="new_password">Password Baru</label>
                                <input type="password" id="new_password" name="new_password" required>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Konfirmasi Password Baru</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>

                            <button type="submit" class="btn">Ubah Password</button>
                        </form>
                    </div>
                </div>

                <div class="profile-card danger">
                    <h2>Hapus Akun</h2>
                    <p class="warning-text">Menghapus akun akan menghapus semua data Anda dan tidak bisa dikembalikan.
                    </p>
                    <form method="POST"
                        onsubmit="return confirm('Apakah Anda yakin ingin menghapus akun ini secara permanen?');">
                        <input type="hidden" name="delete_account" value="1">
                        <button type="submit" class="btn danger">Hapus Akun</button>
                    </form>
                </div>


                <div class="history-card">
                    <h2>Riwayat Pencarian Terakhir</h2>

                    <?php if (empty($search_history)): ?>
                        <p>Belum ada riwayat pencarian</p>
                    <?php else: ?>
                        <ul class="history-list">
                            <?php foreach ($search_history as $item): ?>
                                <li>
                                    <span class="query"><?php echo htmlspecialchars($item['query']); ?></span>
                                    <span class="date"><?php echo htmlspecialchars($item['created_at']); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>

</html>